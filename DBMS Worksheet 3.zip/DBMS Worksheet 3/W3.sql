-- 1.	Create the following table.
-- Employee (Empno: integer, Empname: varchar (20), Job: varchar (20), Dno: integer, Salary: float)

create table employee_sa22521620 (
empno integer primary key,
empname varchar(20),
job varchar(20),
dno integer,
salary float
)

-- 2.	Insert following data into table.


insert into employee_sa22521620 values (100,'Nimal','HR Assistant',1, 25000)
insert into employee_sa22521620 values (101,'Gamini','IT Manager',2,80000)
insert into employee_sa22521620 values (102	,'Supipi','Software Engineer',2,60000)
insert into employee_sa22521620 values (110,'Dev','Project Manager',2,85000)
insert into employee_sa22521620 values (121,'Sahani','Admin Manager',1,70000)
insert into employee_sa22521620 values (107,'Dev','Software Engineer',2,68000)
insert into employee_sa22521620 values (108,'Anuki','Finance Manager',3,70000)
insert into employee_sa22521620 values (114,'Supipi','Software Engineer',2,42000)
insert into employee_sa22521620 values (122,'Janani','Finance Executive',3,	32000)

-- 3.	Answer the following questions.
-- Section A – Practice Questions for Worksheet 02 
--a)	List the employee name and their department number.
Select empname,Dno
from employee_sa22521620

--b)	List the unique job roles in the table.
select distinct Job
from employee_sa22521620

--c)	List all employees who are earning the salary more than 50000.
Select empname
from employee_sa22521620
where Salary>50000

--d)	List the employees who are working as a Software Engineer.
Select empname
from employee_sa22521620
where job = 'Software Engineer'

--e)	List the employees whose name starts with the letter S and salary greater than 40000.
Select distinct empname
from employee_sa22521620
where Salary>40000 and empname like 's%'

--f)	Select the employees whose name ends with the string ‘ni
Select empname
from employee_sa22521620
where empname like '%ni'

--g)	List all the employees that have the letters ‘an’ in its name.
Select empname
from employee_sa22521620
where empname like '%an%'

--h)	Select the employees whose name starts with the letter S and ends with the letter i and department number is 2.
Select empname
from employee_sa22521620
where empname like 's%i' and dno=2

--i)	List the employees where the name second character is the letter a.
Select empname
from employee_sa22521620
where empname like '_a%'

--j)	List the employees whose name starts with A or D and empno is less than to 110.
Select empname
from employee_sa22521620
where empname like '[AD]%' and Empno<110

--k)	Select the employees whose name does not start with S or N.
Select empname
from employee_sa22521620
where empname  like '[^SN]%'

--l)	Select the employees whose name starts with a letter between A and G or job other than Engineer (whose job does not contain the word ‘Engineer’).
Select empname,job
from employee_sa22521620
where empname  like '[A-G]%' or job not like '%Engineer%'


--Section B
--a).	List employees whose employee number is equal to 101, 102 or 114.
Select empname
from employee_sa22521620
where empno = 101 or empno = 102 or empno = 104

Select empname
from employee_sa22521620
where empno in (101,102,104)

--b).	Select emp name and department no of employees whose employee no is not equal to 105, 107 or 122. 
Select empname,dno
from employee_sa22521620
where empno != 105 and empno != 107 and empno != 122

Select empname
from employee_sa22521620
where empno not in (105,107,122)

--c).	List employees whose salary is between 40000 and 100000.
Select empname,dno
from employee_sa22521620
where salary > 40000 and salary < 100000

Select empname,dno
from employee_sa22521620
where salary  between 40000 and 100000

--d).	Select the employees who are Software Engineers and salary not between 50000 and 70000.
Select empname,dno
from employee_sa22521620
where  job like  'Software Engineer' and salary < 50000 and salary > 70000

Select empname,dno
from employee_sa22521620
where  job like  'Software Engineer' and salary not between 50000 and 70000

-- Section C
--a).	List the number of employees in the table.
select count(empno) as 'Number of Employees'
from employee_sa22521620

--b).	Find and display the highest eno. 
select max(empno) as 'Max Employee Number'
from employee_sa22521620

--c).	What is highest salary?
select max(salary) as 'Max Salary'
from employee_sa22521620

--d).	What is the smallest salary?
select min(salary) as 'Min Salary'
from employee_sa22521620

--e).	What is the average salary of an employee?
select Avg(salary) as 'Avg Salary'
from employee_sa22521620

Select round(avg(salary),2)
from employee_sa22521620
where job = 'software engineer'

--f).	How many software engineers are there?
Select count(empno) 
from employee_sa22521620
where job='Software Engineer'

--g).	How many employees are working in the department no 2?
SELECT COUNT(empno)
FROM employee_sa22521620
where dno=2

--h).	How many employees are getting a salary between 50000 and 100000?
SELECT COUNT(empno) as 'Salary between 50000 and 100000'
FROM employee_sa22521620
where salary>=50000 and salary<=100000

SELECT COUNT(empno) as 'Salary between 50000 and 100000'
FROM employee_sa22521620
where salary between 50000 and 100000

--i).	How many employees are there whose name start with D, M or S.?
SELECT COUNT(empno)
FROM employee_sa22521620
where empname like 'd%' or empname like 'm%' or empname like 's%'

SELECT COUNT(empno)
FROM employee_sa22521620
where empname like '[dms]%'

--j).	List the highest salary of a manager. (where job has the word ‘manager’).
SELECT max(salary) as 'max salary'
FROM employee_sa22521620
where job like '%manager%'

--k).	What is the average salary of a software engineer? Round off the average salary to the two decimal places.
Select round(avg(salary),2) as 'average salary of a software engineer'
from employee_sa22521620
where job = 'software engineer'

--l).	What is the total salary paid for employees working in the department no 3?
select sum(salary) as 'total salary paid for employees working in the department no 3'
from employee_sa22521620
where dno=3
