--Insert the new rows into Participate table.
insert into participate_sa22521620 values (114,'Tennis')
insert into participate_sa22521620 values (121,'Tennis')
insert into participate_sa22521620 values (102,'Sailing')

--Write SQL queries to answer the following questions.
--a).	List the name of the youngest player.        
Select pname
from player_sa22521620
where age = (select min(age) from player_sa22521620)

select * from activity_sa22521620

--b).	How many players are participating for the activities for which, activity cost is between 3000 and 4000.
select count(ID)
from participate_sa22521620
where aid in (select aid from activity_sa22521620 where cost between 3000 and 4000)

--c).	List the details of the players who are studying in Methmi�s school.
select *
from player_sa22521620
where school in (select school from player_sa22521620 where pname = 'Methmi')

--d).	List the details of the players whose age is above the average age of a player.
select *
from player_sa22521620
where age >=Any (select avg(age) from player_sa22521620)

--e).	What is the activity with the highest cost?
select aid
from activity_sa22521620
where cost in (select max(cost) from activity_sa22521620)

--f).	What is the activity with the least cost?
select aid
from activity_sa22521620
where cost in (select min(cost) from activity_sa22521620)

--g).	Display the name of the highest paid coach.
select coach
from activity_sa22521620
where cost in (select max(cost) from activity_sa22521620)

--h).	List the details of the players whose age is same as the age of Player ID 100 or 107.
select *
from player_sa22521620
where age in (select age from player_sa22521620 where ID=100 or ID=107)

--i).	List the details of the activities in which the cost is not equal to the cost of the Sailing and the Swimming.
select *
from activity_sa22521620
where cost in (select cost from activity_sa22521620 where aid!='Sailing' OR aid!='Swimming')


--j).	List the activity with the least number of players.
select *
from participate_sa22521620
where aid <=ALL (select aid,count(ID) from participate_sa22521620 group by aid)

select aid,count(ID) 
from participate_sa22521620 
group by aid
having count(ID)  <=ALL (select count(ID) from participate_sa22521620 group by aid)

--k).	Which activity has the highest number of players?
select aid,count(ID) 
from participate_sa22521620 
group by aid
having count(ID)  >=ALL (select count(ID) from participate_sa22521620 group by aid)