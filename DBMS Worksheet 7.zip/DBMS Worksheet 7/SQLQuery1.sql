-- Section A
-- Step 01 - Create Referenced Table
Create table Manager_sa22521620(
mgrid int default 1,
mgrname varchar (20),
experience int,
constraint manager_pk_sa22521620 primary key (mgrid)
)

-- Step 02 - Create Referencing Table
Create table Projects_sa22521620(
ProjNo varchar (5),
MgrID integer, 
Budget float, 
StartDate date, 
Country varchar (20),
constraint projects_pk_sa22521620 primary key (Projno),
constraint manager_fk_sa22521620 foreign key (MgrID) references Manager_sa22521620 (mgrid)
)

insert into Manager_sa22521620 values (3,'Sapumal',8)
insert into Manager_sa22521620 values (4,'Ravi',4)
insert into Manager_sa22521620 values (1,'Nethmi',4)
insert into Manager_sa22521620 values (6,'Sarah',6)
insert into Manager_sa22521620 values (8,'Janith',5)

insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--drop table Projects_sa22521620
--drop table Manager_sa22521620

select *
from Manager_sa22521620

select * 
from Projects_sa22521620

--3. Delete the manager with ID 8. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 8
--4. Delete the manager with ID 3. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3


-- Section B
--Step 01:  Alter the table and drop the foreign key constraint on Project table.
alter table projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Now try to Delete the manager with ID 3. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

--Step 03:  Delete all the records from Project table.
delete 
from Projects_sa22521620

--Step 04:  Add the foreign key with ON DELETE CASCADE option. 
alter table projects_sa22521620
add constraint manager_fk_sa22521620 foreign key (mgrid) references Manager_sa22521620 (mgrid)
on delete cascade

--Step 05:  Insert data into Manager table (The manager record with ID =3 and ID=8) and Project Table.
insert into Manager_sa22521620 values (3,'Sapumal',8)
insert into Manager_sa22521620 values (4,'Ravi',4)
insert into Manager_sa22521620 values (1,'Nethmi',4)
insert into Manager_sa22521620 values (6,'Sarah',6)
insert into Manager_sa22521620 values (8,'Janith',5)

insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 06:  Now delete the Manager with ID 3. Then select all data from both tables. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

select *
from Manager_sa22521620, Projects_sa22521620

--Step 07:  Insert the Manager record with ID is 3.
insert into Manager_sa22521620 values (3,'Sapumal',8)



--Section C: Working with Options: ON DELETE SET NULL
--Step 01:  Alter the table and drop the foreign key constraint on Project table.
alter table Projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Now try to Delete the manager with ID 3. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

--Step 03:  Delete all the records from Project table.
delete
from Projects_sa22521620

--Step 04:  Add the foreign key with ON DELETE SET NULL option. 
alter table projects_sa22521620
add constraint manager_fk_sa22521620 FOREIGN KEY (MgrID) REFERENCES Manager_Sa22521620 (MgrID) ON DELETE SET NULL

--Step 05:  Insert data into Manager table (The manager record with ID =3) and Project Table.
insert into Manager_sa22521620 values (3,'Sapumal',8)

insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 06:  Now delete the Manager with ID 3. Then select all data from both tables. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

select *
from Manager_sa22521620, Projects_sa22521620

--Step 07:  Inset the Manager record with ID is 3.
insert into Manager_sa22521620 values (3,'Sapumal',8)




--Section D: Working with Options: ON DELETE SET DEFAULT
--Step 01:  Alter the table and drop the foreign key constraint on Project table.
alter table Projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Now try to Delete the manager with ID 3. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

select *
from Manager_sa22521620

--Step 03:  Delete all the records from Project table.
delete
from Projects_sa22521620

--Step 04:  Add the foreign key with ON DELETE SET NULL option. 
alter table projects_sa22521620
add constraint manager_fk_sa22521620 FOREIGN KEY (MgrID) REFERENCES Manager_sa22521620 (MgrID) ON DELETE SET default

--Step 05:  Insert data into Manager table (The manager record with ID =3) and Project Table.
insert into Manager_sa22521620 values (3,'Sapumal',8)

insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 06:  Now delete the Manager with ID 3. Then select all data from both tables. Observe and explain the result.
delete
from Manager_sa22521620
where mgrid = 3

select *
from Manager_sa22521620

select *
from Projects_sa22521620

--Step 07:  Inset the Manager record with ID is 3.
insert into Manager_sa22521620 values (3,'Sapumal',8)




--Section E: Working with Options: ON UPDATE CASCADE
--Step 01:  Alter the table and drop the foreign key constraint on Project table.
alter table Projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Delete all the records from Project table.
delete
from Projects_sa22521620

--Step 03:  Add the foreign key with ON UPDATE CASCADE option. 
ALTER TABLE Projects_sa22521620
ADD CONSTRAINT manager_fk_sa22521620 FOREIGN KEY (MgrID) REFERENCES Manager_sa22521620 (MgrID) ON UPDATE CASCADE

--Step 04:  Insert data into Project Table.
insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 05:  Now update the Manager with ID 3 with 10. Then select all data from both tables. Observe and explain the result.
update Manager_sa22521620
set mgrid = 10
where mgrid = 3

select *
from Manager_sa22521620

select *
from Projects_sa22521620



--Section F: Working with Options: ON UPDATE SET NULL
--Step 01:  Alter the table and drop the foreign key constraint on Project table.
alter table Projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Delete all the records from Project table.
delete
from Projects_sa22521620

--Step 03: Update the Manager with ID 10 with 3.
update Manager_sa22521620
set mgrid = 3
where mgrid = 10

--Step 04:  Add the foreign key with ON UPDATE SET NULL option. 
ALTER TABLE Projects_sa22521620
ADD CONSTRAINT manager_fk_sa22521620 FOREIGN KEY (MgrID) REFERENCES Manager_sa22521620 (MgrID) ON UPDATE SET NULL

--Step 05:  Insert data into Project Table.
insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 06:  Now update the Manager with ID 3 with 10. Then select all data from both tables. Observe and explain the result.
update Manager_sa22521620
set mgrid = 10
where mgrid = 3

select *
from Manager_sa22521620

select *
from Projects_sa22521620



--Section G: Working with Options: ON UPDATE SET DEFAULT
--Step 01:  Alter the table and drop the foreign key constraint on Project table
alter table Projects_sa22521620
drop constraint manager_fk_sa22521620

--Step 02:  Delete all the records from Project table.
delete
from Projects_sa22521620

--Step 03: Update the Manager with ID 10 with 3.
update Manager_sa22521620
set mgrid = 3
where mgrid = 10

--Step 04:  Add the foreign key with ON UPDATE SET DEFAULT option. 
ALTER TABLE Projects_sa22521620 
ADD CONSTRAINT manager_fk_sa22521620 FOREIGN KEY (MgrID) REFERENCES Manager_sa22521620 (MgrID) ON UPDATE SET DEFAULT

--Step 05:  Insert data into Project Table.
insert into Projects_sa22521620 values ('P9',3,420000.40,'12-Jul-2019','USA')
insert into Projects_sa22521620 values ('P6',4,650000.50,'2-Jan-2018','USA')
insert into Projects_sa22521620 values ('P4',1,230000.20,'6-Aug-2017','UK')
insert into Projects_sa22521620 values ('P5',3,790000.50,'6-Sep-2019','Australia')
insert into Projects_sa22521620 values ('P2',6,520000.40,'23-Jan-2017','Australia')
insert into Projects_sa22521620 values ('P1',1,420000.40,'23-Feb-2017','UK')
insert into Projects_sa22521620 values ('P3',4,820000.40,'21-Mar-2018','USA')

--Step 06:  Now update the Manager with ID 3 with 10. Then select all data from both tables. Observe and explain the result.
update Manager_sa22521620
set mgrid = 10
where mgrid = 3

select *
from Manager_sa22521620

select *
from Projects_sa22521620