Create table Musician (
MuscianID int, 
MuscianName varchar(30) not null, 
Category varchar(15), 
Rank int default 4, 
Instrument varchar(20),

Constraint m1 Primary key (MuscianID),
Constraint m2  check  (Category = 'Pop' OR Category = 'Rock' OR Category = 'Reggae' OR Category ='Classical')
)

---

Select * from Musician

---

Insert into Musician values ( 12	,'Selena',	'Pop',	4,	'Guitar')
Insert into Musician values ( 14	,'Davis',	'Rock'	,4	,'Piano')
Insert into Musician values ( 15	,'Keanu', 'Reggae',	3,	'Guitar')
Insert into Musician values ( 17	,'Ravi',	'Classical',	5,	'Flute')
Insert into Musician values ( 24	,'Neela',	'Classical',	5,	'Piano')
Insert into Musician values ( 25	,'Kevin',	'Pop',	2	,'Guitar')
Insert into Musician values ( 27	,'Lucas',	'Reggae',	5	,'Flute')
Insert into Musician values ( 29	,'Aiden','Classical',	3	,'Guitar')

---

Insert into Musician values ( 30,null,'Pop',	4,'Guitar')
-- Won't insert due to NULL value
Insert into Musician values ( 32,'Oliver',	'Hiphop',5,'Piano')
-- Conflicts with the CHECK Constraint it won't enter

---

alter table Musician add country varchar(20)

---

update musician 
set country = 'Sri Lanka'
where MuscianID = 12 OR MuscianID = 17

update musician 
set country = 'America'
where MuscianID = 14 OR MuscianID = 25 OR MuscianID = 29

update musician 
set country = 'Brazil'
where MuscianID = 15 OR MuscianID = 27 

update musician 
set country = 'India'
where MuscianID = 24

---
--1
select distinct countries
from musician

--2
select MuscianID,MuscianName
from musician
where country = 'Sri Lanka'

--3
select MuscianName
from musician
where rank < 4 OR Category = 'Classical' 

--4
select *
from musician
where MuscianName like '%n'

--5
select MuscianName
from musician
where MuscianName like '[g-s]%'

--f
select *
from musician
where MuscianID > 20 AND MuscianID < 30

--g
select MuscianName,MuscianID
from musician
where Instrument = 'Piano' OR Instrument = 'Guitar'

--h
select MuscianID,avg(rank)
from Musician
group by MuscianID

select avg(rank)
from musician

--i
select max(rank)
from musician
where country = 'America'

--j
select count(distinct Category)
from musician

--k
select MuscianID,MuscianName,country
from musician
order by country

--l
select Category,Count(MuscianID)
from musician
group by Category
order by category desc

--m
select Instrument, Count(MuscianID)
from musician
group by Instrument
order by Instrument desc

---

---7

delete
from musician
where rank < 3