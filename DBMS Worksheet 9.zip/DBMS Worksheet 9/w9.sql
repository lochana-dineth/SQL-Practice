-- Creating tables
create table player_sa22521620 (
ID int,
pname varchar (20),
age int,
school varchar (20),
constraint player_pk_sa22521620 primary key (ID)
)

create table activity_sa22521620 (
Aid varchar (20),
cost int,
constraint activity_pk_sa22521620 primary key (Aid)    
)

create table participate_sa22521620 (
ID int,
Aid varchar (20),
constraint participate_pk_sa22521620 primary key (ID,Aid),
constraint participate_fk_sa22521620 foreign key (ID) references player_sa22521620 (ID) on delete cascade,
constraint participate_fk2_sa22521620 foreign key (Aid) references activity_sa22521620 (Aid) on delete cascade   
)



-- Inserting Values into Tables
insert into player_sa22521620 values (100,'Ran',5,'Museaus college')
insert into player_sa22521620 values (101,'Ruwan',5,'Royal college')
insert into player_sa22521620 values (102,'Methmi',12,'Museaus')
insert into player_sa22521620 values (07,'Ran',6,'Royal')
insert into player_sa22521620 values (108,'Ruwan',18,'Thurstan')
insert into player_sa22521620 values (110,'Kevin',17,'Royal')
insert into player_sa22521620 values (114,'Ridi',12,'Museaus')
insert into player_sa22521620 values (121,'Dev',14,'Royal')
insert into player_sa22521620 values (122,'Dev',12,'Thurstan')

insert into activity_sa22521620 values ('Swimming',3000)
insert into activity_sa22521620 values ('Golf',5000)
insert into activity_sa22521620 values ('Sailing',6000)
insert into activity_sa22521620 values ('Tennis',5000)
insert into activity_sa22521620 values ('Cricket',3000)
insert into activity_sa22521620 values ('Badminton',3500)

insert into participate_sa22521620 values (122,'Tennis')
insert into participate_sa22521620 values (100,'Swimming')
insert into participate_sa22521620 values (102,'Tennis')
insert into participate_sa22521620 values (110,'Swimming')
insert into participate_sa22521620 values (108,'Sailing')
insert into participate_sa22521620 values (122,'Swimming')
insert into participate_sa22521620 values (102,'Swimming')
insert into participate_sa22521620 values (121,'Swimming')
insert into participate_sa22521620 values (107,'Sailing')
insert into participate_sa22521620 values (121,'Golf')


-- 4. Update the Coach Column
alter table activity_sa22521620 add coach varchar(20)

update activity_sa22521620
set coach = 'Kevin'
where Aid = 'Swimming'

update activity_sa22521620
set coach = 'Jagath'
where Aid = 'Golf'

update activity_sa22521620
set coach = 'Dev'
where Aid = 'Sailing'

update activity_sa22521620
set coach = 'Manju'
where Aid = 'Tennis'

update activity_sa22521620
set coach = 'Peter'
where Aid = 'Cricket'

update activity_sa22521620
set coach = 'Ravi'
where Aid = 'Badminton'

-- 5. Write the Update Commands

update player_sa22521620
set age = 6
where ID = 101

update player_sa22521620
set pname = 'Deva'
where ID = 121

-- 6. Delete Player with ID 107

delete
from Player_sa22521620
where ID = 107

-- 7. Insert a Student
-- Jim aged 12, from ‘Thurstan College’ is a new player. His ID is 123 and he plays sailing as well as swimming. 

insert into player_sa22521620 values (123,'Jim',12,'Thurstan')
insert into participate_sa22521620 values (123,'Swimming')
insert into participate_sa22521620 values (123,'Sailing')

-- 8. Write SQL Queries.
-- a).	List the unique players names.
select distinct ((pname))
from player_sa22521620

-- We can also use Group By for this.

-- b).	List the activities that cost less than 5000.
select Aid
from activity_sa22521620
where cost < 5000

-- c).	List the players whose names start with a letter between G to R. Sort the output in the descending order of name.
select *
from player_sa22521620
where pname like '[G-R]%'
order by pname desc

-- d).	List the player details whose name starts with any character and second character should be ‘e’.
select *
from player_sa22521620
where pname like '_e%'

-- e).	List the players whose age between 10 and 20.
select * 
from Player_sa22521620
where age between 10 and 20

-- f).	What is the highest age of a player?
select (max(age))
from Player_sa22521620

-- g).	List the school name and the number of players from each school.
select school, count(*)
from Player_sa22521620
group by school

-- h).	Display player name, school, activity and coach of each player.
select p.pname,p.school,a.aid,a.coach
from player_sa22521620 p, participate_sa22521620 q, activity_sa22521620 a
where p.id = q.id and a.aid = q.Aid

-- i).	List the name and age of player who participate in swimming.
select p.pname,p.age
from player_sa22521620 p, participate_sa22521620 q
where p.id = q.id and q.aid = 'Swimming'

-- j).	List the schools that have players participating in Tennis.
select p.school
from player_sa22521620 p, participate_sa22521620 q
where p.id = q.id and q.aid = 'Tennis'

-- k).	What is the average age of a player that participates in sailing?
select avg(p.age)
from player_sa22521620 p, participate_sa22521620 q
where p.id = q.id and q.aid = 'Sailing'

-- l).	List the activity and the number of players participating that activity.
select aid, count(ID)
from participate_sa22521620
group by aid

-- m).	List the activities which have more than two participants. Sort the output in descending order of number of participants.
select aid, count(ID)
from participate_sa22521620
group by aid
having count(ID) > 2
order by count(ID) desc

-- n).	What is the total amount a player is spending on activities? List the player ID and the total amount. Select the rows which has a total amount greater than 5000/=.
select q.id,sum (a.cost)
from player_sa22521620 p, participate_sa22521620 q, activity_sa22521620 a
where q.aid = a.aid
group by q.id
having sum(a.cost) > 50000

-- o).	List the coach and the number of players he coaches. Sort the output in the descending order of number of players.
select a.coach, count(*)/10 'NumPlayers'
from player_sa22521620 p, participate_sa22521620 q, activity_sa22521620 a
where q.aid = a.aid 
group by a.coach
order by NumPlayers desc

-- p).	List the coach and the total amount he earns. (total amount=cost x number of players)
select a.coach, (count(*)/10*a.cost) 'NumPlayers'
from player_sa22521620 p, participate_sa22521620 q, activity_sa22521620 a
where q.aid = a.aid 
group by a.coach,a.cost
order by NumPlayers desc

---

Select * from player_sa22521620
Select * from participate_sa22521620
Select * from activity_sa22521620
