-- Step 0
-- Delete all previous records. First we delete from the referencing table and then the referenced tables.
delete from Projects_sa22521620
delete from Manager_sa22521620
-- Then we include the original data set.

select *
from Manager_sa22521620

select *
from Projects_sa22521620

--Section A:
--a)	List all the projects which have a budget between 500 000 and 1000 000.
select *
from projects_sa22521620
where Budget > 500000 AND Budget < 1000000

--b)	Display the project details which are started after 1st of January 2018.
select *
from Projects_sa22521620
where StartDate > '2018-01-01'

--c)	List the project number, budget and country. Sort the output according the country in the ascending order. Each country sorts the subgroup according to the budget in the descending order.
select ProjNo, budget, country
from Projects_sa22521620
order by country asc, budget desc


--d)	Count the number of unique countries in the Projects table.
select count(distinct (country))
from Projects_sa22521620

--e)	List the country and number of projects from each country
select country ,count(country)
from Projects_sa22521620
group by country


--Section B:
--a)	Display managers ID and the project numbers they manage.
select *
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID
    
--b)	List all the project number, manager�s name and country of those manager�s name that start with a letter between A to S.
select p.projno, m.mgrname, p.country
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID and mgrname like '[A-S]%'

--c)	List the project numbers and their budgets of those that are managed by managers with more than 5 years of experience.
select p.projno, p.Budget
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID and experience > 5

--d)	List the project numbers, budget and manager names of all the projects which have a budget not between 500 000 and 1000 000.
select p.projno, p.Budget, m.mgrname
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID and budget not between 500000 and 1000000

--e)	List the project manager�s name, experience and project budget. Sort the output according to manager�s name in the ascending order, and the subgroups according to budget in the descending order.
select  m.mgrname,m.experience,p.Budget
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID
order by mgrname asc, budget desc


--Section C:
--a)	List the manager ID and the number of projects they manage. Sort the output in the descending order of number of projects.
select m.mgrid, count(projno) as No_projects
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID
group by m.mgrid
order by No_projects desc

--b)	List the manager�s ID and the number of projects they manage of those whose experience is less than 5 years.
select m.mgrid, count(projno) as No_projects
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID and m.experience < 5
group by m.mgrid
order by No_projects desc

--c)	List the manager ID and average budget of a project he/she manages. Round off the budget to the nearest rupee.
select m.mgrid, round(avg(budget),0) as average_budget
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID
group by m.mgrid

--d)	List the manager ID and average budget of a project he/she manages. Round off the budget to the nearest ten thousand.
select m.mgrid, round(avg(budget),-4) as average_budget
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID
group by m.mgrid

--e)	List the manager ID and average budget of a project he/she manages of those with an average budget less than Rs 600 000.
select m.mgrid, avg(budget) as average_budget
from Manager_sa22521620 m, Projects_sa22521620 p
where m.mgrid = p.MgrID 
group by m.mgrid
having avg(budget) < 600000


-- SQL JOIN 
-- Left Outer Join
select *
from Manager_sa22521620 m left join Projects_sa22521620 p
on m.mgrid = p.mgrid

select *
from Manager_sa22521620 m right join Projects_sa22521620 p
on m.mgrid = p.mgrid

select *
from Manager_sa22521620 m full outer join Projects_sa22521620 p
on m.mgrid = p.mgrid