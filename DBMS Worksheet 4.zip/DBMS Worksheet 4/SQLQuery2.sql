
select * 
from employee_sa22521620

insert into employee_sa22521620 values (124,'Danuki','Finance Executive',3,32000)
insert into employee_sa22521620 values (125,'Methmi','Admin Support',1,22000)
insert into employee_sa22521620 values (127,'Malik','Research Assistant',4,56000)
insert into employee_sa22521620 values (134,'Chathuri','Software Engineer',3,56000)

select count (distinct Empno)
from employee_sa22521620

--Section A
--a).	How many unique jobs are there in the employee table?
select count (distinct job)
from employee_sa22521620

--b).	List the employee number and the name. Sort the output in the ascending order of employee name. 
select empno, empname
from employee_sa22521620
order by empname asc

--c).	List all employees whose name start with a letter between C and M. Sort the output in the descending order of employee name.
select *
from employee_sa22521620
where empname like '[C-M]%'
order by empname desc

--d).	List the Job and salary of all the employees. Sort the output in descending order of Job and ascending order of salary.
select job,salary
from employee_sa22521620
order by job desc, salary asc


--Section B
--a).	List the department number and the number of employees from each department.
select dno, count(distinct empno) as 'Number of Employees'
from employee_sa22521620
group by dno

--b).	List the department number and the number of employees from each department. Sort the output according to the number of employees in the ascending order.
select dno, count(distinct empno) as 'Number of Employees'
from employee_sa22521620
group by dno
order by [Number of Employees] asc

select dno, count(distinct empno) as 'Number of Employees'
from employee_sa22521620
group by dno
order by 2 asc

select dno, count(distinct empno) as 'Number of Employees'
from employee_sa22521620
group by dno
order by count(*) asc

--c).	List the department number and the number of employees from each department. List only the department with more than 2 employees. Sort the output according to the number of employees in the descending order.
select dno, count(distinct empno) as 'Number of Employees'
from employee_sa22521620
group by dno
having count(distinct empno) > 2
order by [Number of Employees] desc


--d).	List the department number and the highest salary of each department. Sort the output according to the highest salary in the descending order.
select dno, max(salary)
from employee_sa22521620
group by dno
order by max(salary) desc

--e).	Display the department number and number of unique job types are in each department.
select dno, count (distinct job)
from employee_sa22521620
group by dno

--f).	List the Job name and no of employees each job type. Sort the output according to the Job name in the descending order.
select job, count (empno)
from employee_sa22521620
group by job
order by job desc

--g).	List the dno and the number of employees whose name start with a letter between C and S. Sort the output in the ascending order of number of employees.
select dno, count(distinct empname)
from employee_sa22521620
where empname like '[c-s]%'
group by dno
order by count(empname) desc


--h).	List the dno and the number of employees whose name start with a letter between C and S. List only the department with more than 2 such employees. Sort the output in the ascending order of number of employees.
select dno, count(distinct empname)
from employee_sa22521620
where empname like '[c-s]%'
group by dno
having count(empname) > 2
order by count(empname) desc