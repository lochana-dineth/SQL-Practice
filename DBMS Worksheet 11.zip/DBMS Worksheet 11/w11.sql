create table books_sa22521620 (
bookid int,
title varchar (20),
category varchar (20),
constraint books_c1 primary key (bookid),
constraint books_c2 check (bookid between 1 and 4000),
constraint books_c3 check (category in ('Motivation','Psychology','Programming'))
)

create table borrowed_sa22521620 (
BookID int, 
MemberID varchar (20), 
BorrowedDate date, 
ReturnDate date, 
Status varchar (10)
constraint borrowed_c1 primary key (bookid,memberId,borrowedDate),
constraint borrowed_c2 foreign key (BookID) references books_sa22521620 (bookid)
)        

-- Inserting the Values
insert into books_sa22521620 values (1200,'The Idea in You','Motivation')
insert into books_sa22521620 values (1300,'Dream Psychology','Psychology')
insert into books_sa22521620 values (1201,'Self-Belief','Motivation')
insert into books_sa22521620 values (1001,'C Programming','Programming')
insert into books_sa22521620 values (1006,'Java','Programming')

insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1200,'M106','21-Jun-2019','In')
insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1001,'M108','21-Jan-2018','In')
insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1200,'M106','2-Feb-2020','Out')
insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1001,'M102','3-Jan-2017','In')
insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1006,'M103','15-Mar-2017','Out')
insert into borrowed_sa22521620 (BookID,MemberID,BorrowedDate,Status) values (1200,'M108','2-Jan-2020','Out')

select * from books_sa22521620
select * from borrowed_sa22521620

select getdate() as 'Current Date and Time'

select datepart(yy,'21-Jun-2019')

select datepart(wk,GETDATE()) as 'Week'
select datename(wk,GETDATE()) as 'Week'

select datepart(yy,GETDATE()) as 'Year'
select datename(yy,GETDATE()) as 'Year'

select datepart(mm,GETDATE()) as 'Month'
select datename(mm,GETDATE()) as 'Month'

select datepart(dy,GETDATE()) as 'Day of Year'
select datename(dy,GETDATE()) as 'Day of Year'

select datepart(dd,GETDATE()) as 'Day'
select datename(dd,GETDATE()) as 'Day'

select datepart(dw,GETDATE()) as 'WeekDay'
select datename(dw,GETDATE()) as 'WeekDay'

select year(getdate()) as 'Year'
select month(GETDATE()) as 'Month'
select day(GETDATE()) as 'Day'

select dateadd(yy,2,GETDATE())
select dateadd(yy,-2,GETDATE())

select DATEDIFF(yy,'2002-08-19',GETDATE())
select DATEDIFF(ww,'2002-08-19',GETDATE())

-- 3) SQL Queries.
--a)On what day of the week was book 1006 borrowed?
select DATENAME(dw,borroweddate)
from borrowed_sa22521620
where bookid = '1006'
--b)On what week of the year was book 1006 borrowed?
select DATENAME(ww,borroweddate)
from borrowed_sa22521620
where bookid = '1006'

--c)Return date is two months from the borrowed date. Update the ReturnDate column, using date time functions.
update borrowed_sa22521620
set ReturnDate = dATEADD(mm,2,BorrowedDate)

--d)The book 1200 borrowed on 21-June-2019 has not returned by member M106. Calculate the number of overdue months. 
select DATEDIFF(mm,Borroweddate,GETDATE()) as 'Overdure Months'
from borrowed_sa22521620
where MemberID = 'M106' and BookID = 1200 and borroweddate = '21-June-2019'

--e)Find out which day of the week you were born on.
select DATENAME(dw,'2002-08-19')

--f)Calculate your age in months.
select DATEDIFF(mm,'2002-08-19',GETDATE())

--g)Calculate your age in weeks.
select DATEDIFF(ww,'2002-08-19',GETDATE())

--h)List the unique categories of books.
select distinct(category)
from books_sa22521620

--i)List the member id and the number of times that have borrowed.
select memberid, count (memberid)
from borrowed_sa22521620
group by MemberID

--j)List the book Id and title of the books borrowed by M106.
select a.title, b.BookID , b.MemberID
from books_sa22521620 a, borrowed_sa22521620 b
where MemberID = 'M106' and a.bookid = b.BookID

--k)List the member Ids of those who have borrowed Motivation books.
select b.MemberID, a.category
from borrowed_sa22521620 b, books_sa22521620 a
where a.bookid = b.BookID and a.category= 'Motivation' 

--l)	List the book category and the number of books from each category.
select category, count(*)
from books_sa22521620
group by category

--m)Display the titles of all the books which are borrowed in the month �January�
select a.title
from books_sa22521620 a, borrowed_sa22521620 b
where a.bookid = b.BookID and month(BorrowedDate) = '1'

--n)Display the Book ID of the most borrowed book.
select BookID
from borrowed_sa22521620
group by BookID
having count(*)>all(SELECT COUNT (*) from borrowed_sa22521620, group by BookID)

--o)Display the title of the book with the smallest book ID.
select a.title
from books_sa22521620 a
where a.bookid in (select min(BookID) from books_sa22521620)

select a.title
from books_sa22521620 a
where a.bookid = (select min(bookid) from books_sa22521620)

select b.title
from books_sa22521620 b
where b.bookid >=All(select bookid from books_sa22521620)