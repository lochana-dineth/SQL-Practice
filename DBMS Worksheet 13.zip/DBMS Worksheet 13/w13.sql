create table chef_sa22521620 (
id int,
chefname varchar (30),
specialty varchar (30),
rank int,
constraint chef_sa22521620_c1 primary key (id),
constraint chef_sa22521620_c6 check (specialty in ('Indian','Italian','SriLankan'))
)

create table food_sa22521620 (
id varchar (20),
foodname varchar (40),
price int,
rating int,
chefid int,
constraint food_sa22521620_c2 primary key (id),
constraint food_sa22521620_c3 foreign key (chefid) references chef_sa22521620 (id),
constraint food_sa22521620_c4 check (rating between 1 and 5)
)

-- Insert into Tables
Insert into chef_sa22521620 values (12,'Sripa','Indian',5)
Insert into chef_sa22521620 values (14,'Dilma','Italian',7)
Insert into chef_sa22521620 values (15,'Keanu','Italian',6)
Insert into chef_sa22521620 values (17,'Ravi','SriLankan',8)
Insert into chef_sa22521620 values (24,'Neela','SriLankan',9)

Insert into food_sa22521620 values ('F12','Indian chicken masala',340,3,12)
Insert into food_sa22521620 values ('F15','Pasta al pesto',650,4,14)
Insert into food_sa22521620 values ('F34,','Ravioli Klotznnudl',900,3,14)
Insert into food_sa22521620 values ('F42','Risotto ai gamberoni',800,3,14)
Insert into food_sa22521620 values ('F25','Fish Ambul thiyal',400,5,17)
Insert into food_sa22521620 values ('F24','Polos curry',300,5,17)
Insert into food_sa22521620 values ('F45','Watalappan',250,5,14)
Insert into food_sa22521620 values ('F46','Kalu dodol',400,5,24)
Insert into food_sa22521620 values ('F58','Paper Those',200,4,12)
Insert into food_sa22521620 values ('F57','Idly',100,5,12)

-- Adding a new Column to the Chef Table

alter table chef_sa22521620 add joined_date date

select * from chef_sa22521620

-- Update Table

update chef_sa22521620 set joined_date = '21-Jun-2016' where id=12
update chef_sa22521620 set joined_date = '21-Mar-2014' where id=14
update chef_sa22521620 set joined_date = '2-Feb-2015' where id=15
update chef_sa22521620 set joined_date = '3-Jan-2017' where id=17
update chef_sa22521620 set joined_date = '15-Mar-2017' where id=24

-- 5.	List chef ID, name, specialty, and rank of chefs who are specialized in Sri Lankan food. 
select id,chefname,specialty,rank
from chef_sa22521620
where specialty = 'SriLankan'

-- 6.	List the chef details in which name starts with any character and second character e.
select *
from chef_sa22521620
where chefname like '_e%'

-- 7.	List the food names whose names start with a letter between H to P. Sort the output in the ascending order of food name.
select *
from food_sa22521620
where foodname like '[H-P]%'
order by foodname asc


-- 8.	List chef ID, name and food name of those who make a food item with a rating 4 or 5.
select c.id, c.chefname, f.foodname
from chef_sa22521620 c, food_sa22521620 f
where c.id = f.chefid and f.rating = 4 or f.rating = 5


-- 9.	List the food names in which are priced between 400 and 700.	
select foodname, price
from food_sa22521620
where price between 400 and 700


-- 10.	List the Chefs who make more than 2 food items. List chef ID, name and number of items. Sort the output based on the number of items in descending order.
SELECT f.chefid, c.chefname, COUNT(f.chefid)
FROM food_sa22521620 f, chef_sa22521620 c 
where f.chefid = c.id
GROUP BY f.chefid, c.chefname
having count(f.chefid) >2
ORDER BY COUNT(f.chefid) DESC;


-- 11.	List the chef ID and name of the chef who prepared the food item with the highest price.      
select c.id, c.chefname
from chef_sa22521620 c, food_sa22521620 f
where c.id = f.chefid and f.price in (select max(price) from food_sa22521620)

select c.id, c.chefname
from chef_sa22521620 c, food_sa22521620 f
where c.id = f.chefid and f.price = (select max(price) from food_sa22521620)

select c.id, c.chefname
from chef_sa22521620 c, food_sa22521620 f
where c.id = f.chefid and f.price >= (select max(price) from food_sa22521620)

-- 12.	What is the average price of food prepared by chef ‘Dilma’? 	    	     
select avg(f.price)
from food_sa22521620 f, chef_sa22521620 c
where c.id = f.chefid and c.chefname = 'Dilma'


-- 13.	Display the Food details in which price is greater than to the average price of all the foods.
select *
from food_sa22521620
where price >=Any (select avg(price) from food_sa22521620)


-- 14.	List the chef ID who prepared most number of food items.
select chefid
from food_sa22521620
group by chefid
having count(*) >=ALL(select count(*) from food_sa22521620 group by chefid)


-- 15.	List the chef details of those who joined in the month ‘March’.
select *
from chef_sa22521620
where month(joined_date) = 3

-- 16.	List the chef details along with their experience in years. Hint: Experience in years is calculated as the difference between system date and the JoinedDate Attribute.
select *, datediff (yy,  joined_date,getdate()) as 'Experience'
from chef_sa22521620

--17.	Create a view ‘TopFood’ with columns Food ID, name, price, rating and Chef name. This view contains food items which are priced between 500 and 1000 and has a rating above 3. 

create view Topfood_SA22521620 as
select f.id, f.foodname, f.price, f.rating, c.chefname
from food_sa22521620 f, chef_sa22521620 c
where c.id = f.chefid and f.price between 500 and 1000 and f.rating > 3

select * from Topfood_SA22521620



